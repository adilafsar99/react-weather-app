import {useState} from 'react';
import "./css/index.css";

function City_Input({getCityName}) {
  const [value, setValue] = useState("");
  const id = "city-input";
  return(
    <div className="city-input-div">
       <input class="input-box" id={id} type="text" value={value} onChange={(e) => setValue(e.target.value)} placeholder="Enter city"/>
       <button class="input-box-btn" onClick={() => getCityName(id, value)}>Get Weather</button>
    </div>
  )
}

export {City_Input};