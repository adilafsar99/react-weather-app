import {useState, useEffect} from 'react';
import "./css/index.css";

function Weather_Report({lon, lat, cityName}) {
  const [json, setJson] = useState("");
  let locationQuery = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=d673a601220ef2d08649dbcc24ffab33&units=metric`;
  let cityQuery = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=d673a601220ef2d08649dbcc24ffab33&units=metric`;
  useEffect(() => {
    fetch(cityName ? cityQuery : locationQuery)
  .then(response => response.json())
  .then(json => setJson(json))
  }, [lon, lat, cityName])
  return(
    <div className="weather-report-div">
      <div className="weather-report">
       <div className="city-name">
         <h2>{json && json.name}</h2>
       </div>
       <div className="weather">
         <p>{json.weather && `Weather: ${json.weather[0].description.slice(0,1).toUpperCase() + json.weather[0].description.slice(1)}`}</p>
       </div>
       <div className="temperature">
         <p>{json.main && `Temperature: ${json.main.temp}°C`}</p>
       </div>
       <div className="feels-like">
         <p>{json.main && `Feels like: ${json.main.feels_like}°C`}</p>
       </div>
    </div>
  </div>
  )
}

export {Weather_Report};