import {useState} from 'react';
import {City_Input} from "./City_Input";
import {Weather_Report} from "./Weather_Report";
import "./index.css";

function Weather_App() {
  const [cityName, setCityName] = useState("");
  const [lon, setLon] = useState("");
  const [lat, setLat] = useState("");
  const getLocation = () => {
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition((location) => {
        resolve(location)
      })
    })
  }
  const saveLocation = async () => {
     const location = await getLocation();
     setLon(location.coords.longitude);
     setLat(location.coords.latitude);
  }
  saveLocation();
  const getCityName = (id, city) => {
    let invalidCity = true;
    if (city.length !== 0) {
      invalidCity = false;
    }
    for (let i = 0; i < city.length; i++) {
      if (city[i] !== "") {
        invalidCity = false;
        break;
      }
    }
    for (let i = 0; i < city.length; i++) {
      if (Number(city[i]) != city[i]) {
        invalidCity = false;
        break;
      }
    }
    if (invalidCity) {
      let input = document.getElementById(id);
      input.focus();
    }
    if (!invalidCity) {
      setCityName(city)
    }
  }
  return(
    <div className="weather-app">
       <div className="heading">
          <h1>Weather Teller</h1>
       </div>
       <City_Input getCityName={getCityName} />
       <Weather_Report lon={lon} lat={lat} cityName={cityName}/>
    </div>
  )
}

export {Weather_App};