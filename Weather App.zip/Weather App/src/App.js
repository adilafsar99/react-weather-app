import "./App.css";
import {Weather_App} from "./components"

function App() {
   return (
     <Weather_App />
   )
}

export default App;